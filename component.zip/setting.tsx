import React from 'react';

export const Setting: React.FC = () => {
  return <div>Component Setting</div>;
};
