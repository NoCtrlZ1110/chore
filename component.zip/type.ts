export interface ComponentInterface {
    text: string;
}
