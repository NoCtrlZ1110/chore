import React from 'react';

export const QuickSetting: React.FC = () => {
  return <div>QuickSetting</div>;
};
