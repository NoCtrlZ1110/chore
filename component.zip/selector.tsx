import { AdvanceAttributes, withSelector } from '@tempi/core-editor';
import { ComponentUI } from './ui';
import { QuickSetting } from './quick-setting';
import { Setting } from './setting';
import { DEFAULT_COMPONENT_PROPS } from './constant';

export const ComponentEditor = withSelector(ComponentUI, {
  displayName: 'Component name',
  tag: ComponentUI.displayName.toLowerCase(),
  quickSetting: QuickSetting,
  customAttributes: Setting,
  props: DEFAULT_COMPONENT_PROPS,
  advanceAttributes: AdvanceAttributes,
  commonAttributes: Setting,
});
