import React from 'react';
import { ComponentInterface } from './type';

export const ComponentUI: React.FC<ComponentInterface> = (props) => {
  const { text } = props;
  return <div>{text}</div>;
};

ComponentUI.displayName = 'ComponentUI';
