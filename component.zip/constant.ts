import { ComponentInterface } from './type';

export const DEFAULT_COMPONENT_PROPS: ComponentInterface = {
  text: 'Lorem ipsum',
};
